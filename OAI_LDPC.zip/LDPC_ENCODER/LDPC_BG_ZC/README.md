gcc -ldpc176_byte_test.c -mfma -Wall
This test is used to check the part of parity code when BG is one and Zc is 176.
