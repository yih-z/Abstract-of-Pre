gcc nrLDPC_decoder.c time_meas.c -mavx2 -Wall
